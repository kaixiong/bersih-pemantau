-- MySQL dump 10.13  Distrib 5.5.31, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: citkcoid_pru13
-- ------------------------------------------------------
-- Server version	5.5.31-0ubuntu0.12.10.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `form`
--

DROP TABLE IF EXISTS `form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `form_title` varchar(200) NOT NULL,
  `form_description` text,
  `form_active` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `form_title` (`form_title`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='Stores all report submission forms created(default+custom)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form`
--

LOCK TABLES `form` WRITE;
/*!40000 ALTER TABLE `form` DISABLE KEYS */;
INSERT INTO `form` VALUES (1,'Default Form','Default form, for report entry',1);
/*!40000 ALTER TABLE `form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `form_field`
--

DROP TABLE IF EXISTS `form_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_field` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `form_id` int(11) NOT NULL DEFAULT '1',
  `field_name` varchar(200) DEFAULT NULL,
  `field_type` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1 - TEXTFIELD, 2 - TEXTAREA (FREETEXT), 3 - DATE, 4 - PASSWORD, 5 - RADIO, 6 - CHECKBOX',
  `field_required` tinyint(4) DEFAULT '0',
  `field_position` tinyint(4) NOT NULL DEFAULT '0',
  `field_default` text,
  `field_maxlength` int(11) NOT NULL DEFAULT '0',
  `field_width` smallint(6) NOT NULL DEFAULT '0',
  `field_height` tinyint(4) DEFAULT '5',
  `field_isdate` tinyint(4) NOT NULL DEFAULT '0',
  `field_ispublic_visible` int(11) NOT NULL DEFAULT '0',
  `field_ispublic_submit` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `field_name` (`field_name`,`form_id`),
  KEY `fk_form_id` (`form_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COMMENT='Stores all custom form fields created by users';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form_field`
--

LOCK TABLES `form_field` WRITE;
/*!40000 ALTER TABLE `form_field` DISABLE KEYS */;
INSERT INTO `form_field` VALUES (2,1,'No.Tel/HP (Hanya untuk pengesahan aduan)',1,1,3,NULL,0,0,5,0,0,0),(3,1,'Lokasi Kesalahan Berlaku',1,0,4,NULL,0,0,5,0,0,0),(4,1,'NO.I.C (Kad Pengenalan)',1,1,2,NULL,0,0,5,0,2,0),(8,1,'Saya sedia memberi kenyataan berkenaan aduan ini',5,1,4,'Ya,Tidak',0,0,5,0,0,0),(7,1,'Saya mempunyai bukti video',5,1,5,'Ya,Tidak',0,0,5,0,0,0),(9,1,'Parliament Seat',1,1,6,NULL,0,0,5,0,0,0),(10,1,'State Seat',1,0,7,NULL,0,0,5,0,0,0);
/*!40000 ALTER TABLE `form_field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `form_field_option`
--

DROP TABLE IF EXISTS `form_field_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_field_option` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `form_field_id` int(11) NOT NULL DEFAULT '0',
  `option_name` varchar(200) DEFAULT NULL,
  `option_value` text,
  PRIMARY KEY (`id`),
  KEY `form_field_id` (`form_field_id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COMMENT='Options related to custom form fields';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form_field_option`
--

LOCK TABLES `form_field_option` WRITE;
/*!40000 ALTER TABLE `form_field_option` DISABLE KEYS */;
INSERT INTO `form_field_option` VALUES (1,1,'field_datatype','text'),(2,1,'field_hidden','0'),(3,2,'field_datatype','text'),(4,2,'field_hidden','0'),(5,3,'field_datatype','text'),(6,3,'field_hidden','1'),(7,4,'field_datatype','text'),(8,4,'field_hidden','0'),(11,9,'field_datatype','text'),(12,9,'field_hidden','1'),(13,10,'field_datatype','text'),(14,10,'field_hidden','1');
/*!40000 ALTER TABLE `form_field_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `locale` varchar(10) NOT NULL DEFAULT 'en_US',
  `category_position` tinyint(4) NOT NULL DEFAULT '0',
  `category_title` varchar(255) DEFAULT NULL,
  `category_description` text,
  `category_color` varchar(20) DEFAULT NULL,
  `category_image` varchar(255) DEFAULT NULL,
  `category_image_thumb` varchar(255) DEFAULT NULL,
  `category_visible` tinyint(4) NOT NULL DEFAULT '1',
  `category_trusted` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `category_visible` (`category_visible`),
  KEY `parent_id` (`parent_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1010 DEFAULT CHARSET=utf8 COMMENT='Holds information about categories defined for a deployment';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,0,'en_US',17,'Politik wang','Politik wang','9900CC',NULL,NULL,1,0),(6,0,'en_US',18,'Dakwat kekal','Dakwat kekal','85bbf5',NULL,NULL,1,0),(3,0,'en_US',19,'Salah guna kuasa','Salah guna kuasa','663300',NULL,NULL,1,0),(4,0,'en_US',23,'Trusted Reports','Reports from trusted reporters','339900',NULL,NULL,0,1),(999,0,'en_US',0,'Daftar pemilih','Daftar pemilih','f7aa11',NULL,NULL,1,0),(7,0,'en_US',20,'Undi Pos','Undi Pos','f50a58',NULL,NULL,1,0),(8,0,'en_US',7,'Keganasan/Kekacauan/Ugutan/Pergaduhan','Keganasan/Kekacauan/Ugutan/Pergaduhan','fa0505',NULL,NULL,1,0),(9,0,'en_US',8,'Ganguan untuk berkempen','Ganguan untuk berkempen','0c2ad4',NULL,NULL,1,0),(10,0,'en_US',9,'Penyamaran/Pengundi ragu','Penyamaran/Pengundi ragu','e86112',NULL,NULL,1,0),(11,0,'en_US',10,'Sogokan/Penjamuan/Beli Undi','Sogokan/Penjamuan/Beli Undi','00ff40',NULL,NULL,1,0),(12,0,'en_US',11,'Halangan/Tidak dapat mengundi','Halangan/Tidak dapat mengundi','eb3676',NULL,NULL,1,0),(13,0,'en_US',16,'Salah guna kemudahan awam/Jentera','Salah guna kemudahan awam/Jentera','00c4ff',NULL,NULL,1,0),(14,999,'en_US',3,'Tidak Pernah mendaftar tetapi nama terdapat dalam daftar pemilih','Tidak Pernah mendaftar tetapi nama terdapat dalam daftar pemilih','ff00ff',NULL,NULL,1,0),(15,0,'en_US',22,'Lain-lain','Lain-lain','c3d100',NULL,NULL,1,0),(1000,999,'ms_MY',1,'Nama hilang (pernah undi PRU12)','Nama hilang (pernah undi PRU12)','f5d81e',NULL,NULL,1,0),(1001,999,'ms_MY',2,'Parlimen/DUN mengundi ditukar','Parlimen/DUN mengundi ditukar','8400ff',NULL,NULL,1,0),(1002,999,'ms_MY',4,'Pengundi ragu','Pengundi ragu','bf00a9',NULL,NULL,1,0),(1003,999,'ms_MY',5,'Ada orang mengundi atas nama anda','Ada orang mengundi atas nama anda','700070',NULL,NULL,1,0),(1004,999,'ms_MY',6,'Penyamaran','Penyamaran','520052',NULL,NULL,1,0),(1005,12,'ms_MY',12,'Kertas undi','Kertas undi','00eeff',NULL,NULL,1,0),(1006,12,'ms_MY',13,'Tidak dicop','Tidak dicop','00ded3',NULL,NULL,1,0),(1007,12,'ms_MY',14,'Ada tanda','Ada tanda','009494',NULL,NULL,1,0),(1008,12,'ms_MY',15,'Tidak dibenarkan untuk menukar kertas undi yang mempunyai masalah','Tidak dibenarkan untuk menukar kertas undi yang mempunyai masalah','005359',NULL,NULL,1,0),(1009,0,'ms_MY',21,'Isu di Pusat Penjumlahan rasmi undi','Isu di Pusat Penjumlahan rasmi undi','006624',NULL,NULL,1,0);
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category_lang`
--

DROP TABLE IF EXISTS `category_lang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category_lang` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(11) unsigned NOT NULL,
  `locale` varchar(10) DEFAULT NULL,
  `category_title` varchar(255) DEFAULT NULL,
  `category_description` text,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 COMMENT='Holds translations for category titles and descriptions';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category_lang`
--

LOCK TABLES `category_lang` WRITE;
/*!40000 ALTER TABLE `category_lang` DISABLE KEYS */;
INSERT INTO `category_lang` VALUES (1,5,'en_US','',NULL),(2,5,'fr_FR','',NULL),(3,1,'en_US','Politik wang','Politik wang'),(4,1,'fr_FR','',NULL),(5,3,'en_US','Salah guna kuasa','Salah guna kuasa'),(6,3,'fr_FR','',NULL),(7,6,'en_US','Dakwat kekal','Dakwat kekal'),(8,6,'fr_FR','',NULL),(9,7,'en_US','Undi Pos','Undi Pos'),(10,7,'fr_FR','',NULL),(11,8,'fr_FR','',NULL),(12,8,'en_US','Keganasan/Kekacauan/Ugutan/Pergaduhan','Keganasan/Kekacauan/Ugutan/Pergaduhan'),(13,9,'en_US','Ganguan untuk berkempen','Ganguan untuk berkempen'),(14,9,'fr_FR','',NULL),(15,10,'en_US','Penyamaran/Pengundi ragu','Penyamaran/Pengundi ragu'),(16,10,'fr_FR','',NULL),(17,11,'en_US','Sogokan/Penjamuan/Beli Undi','Sogokan/Penjamuan/Beli Undi'),(18,11,'fr_FR','',NULL),(19,12,'en_US','Halangan/Tidak dapat mengundi','Halangan/Tidak dapat mengundi'),(20,12,'fr_FR','',NULL),(21,13,'en_US','Salah guna kemudahan awam/Jentera','Salah guna kemudahan awam/Jentera'),(22,13,'fr_FR','',NULL),(23,14,'en_US','Tidak Pernah mendaftar tetapi nama terdapat dalam daftar pemilih','Tidak Pernah mendaftar tetapi nama terdapat dalam daftar pemilih'),(24,14,'fr_FR','',NULL),(25,15,'en_US','Lain-lain','Lain-lain'),(26,15,'fr_FR','',NULL);
/*!40000 ALTER TABLE `category_lang` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `page`
--

DROP TABLE IF EXISTS `page`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_title` varchar(255) NOT NULL,
  `page_description` longtext,
  `page_tab` varchar(100) NOT NULL,
  `page_active` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='Stores user created pages';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page`
--

LOCK TABLES `page` WRITE;
/*!40000 ALTER TABLE `page` DISABLE KEYS */;
INSERT INTO `page` VALUES (2,'Cara membuat aduan','<p>Pastikan semua aduan mempunyai bukti yang sahih \nseperti gambar, video, butiran pemberi maklumat dan \nsebagainya.</p>\n\n<p>Sebarang aduan berkenaan \npilihanraya boleh dibuat melalui salah satu cara \nberikut:</p>\n\n<ol><li>Email kepada \n<a href=\"mailto:jompantau@komas.org\">jompantau@komas.org</a></li><li>Isikan borang \nonline (tekan \"Isi borang \naduan\")</li><li>Hantar SMS \nke 013-7711071</li><li>Talian \naduan 03-79310840</li><li>Hantar tweet ke \n#jompantau</li></ol>\n\n<p>Cara untuk menghantar \nSMS:</p>\n<p>Sila taip: nama penghantar, apa \nkesalahan, pelaku kesalahan, tempat &amp; masa kesalahan dan hantar \nke 013-7711071</p>','Cara Buat Aduan',1);
/*!40000 ALTER TABLE `page` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-05-14 11:39:57
